#!/bin/bash
hadoop fs -touchz /tmp/azkaban_event/SQOOP_ODS_IPS_TIKU_$(date+"%Y%m%d").event
