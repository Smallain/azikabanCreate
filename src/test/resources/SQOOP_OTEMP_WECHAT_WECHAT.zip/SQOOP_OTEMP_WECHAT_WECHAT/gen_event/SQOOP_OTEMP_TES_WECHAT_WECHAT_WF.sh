#!/bin/bash
hadoop fs -touchz /tmp/azkaban_event/SQOOP_OTEMP_TES_WECHAT_WECHAT_$(date+"%Y%m%d").event
